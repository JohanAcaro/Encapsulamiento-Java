package com.segundo;

import com.primero.Coche;

public class Comprar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Coche coche1 = new Coche(1,"renault",12300.85f);
		Coche coche2 = new Coche(2,"seat",27678.75f);
		Coche coche3 = new Coche(3,"toyota",23022.65f);
		Coche coche4 = new Coche(4,"hyunday",24345.97f);
		
		float precioCoche3 = coche3.getPrecio();
		System.out.println("el precio del coche 3 es "+precioCoche3);
	}

}
